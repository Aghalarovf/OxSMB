// SmbRecon.Core.Tests / Abstractions / SmbToolBaseTests.cs
// Step 3/10 — exception -> ToolResult(Success=false) contract test
// TODO: implement tests
