// SmbRecon.Core.Tests / Models / FindingTests.cs
// TODO: implement tests
