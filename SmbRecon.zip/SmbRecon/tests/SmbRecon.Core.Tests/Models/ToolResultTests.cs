// SmbRecon.Core.Tests / Models / ToolResultTests.cs
// TODO: implement tests
