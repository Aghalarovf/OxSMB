// SmbRecon.Core.Tests / Models / SmbTargetTests.cs
// Step 2/10 — record equality + with-expression cloning tests
// TODO: implement tests
