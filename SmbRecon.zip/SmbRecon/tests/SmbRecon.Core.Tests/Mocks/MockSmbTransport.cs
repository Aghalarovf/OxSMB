using SmbRecon.Core.Abstractions;
using SmbRecon.Core.Models;

namespace SmbRecon.Core.Tests.Mocks;

public sealed class MockSmbTransport : ISmbTransport
{
    private readonly Queue<byte[]> _responses;

    public MockSmbTransport(params byte[][] responses)
    {
        _responses = new Queue<byte[]>(responses);
    }

    public bool IsConnected { get; private set; }

    public List<byte[]> SentRequests { get; } = new();

    public Task ConnectAsync(SmbTarget target, CancellationToken ct)
    {
        IsConnected = true;
        return Task.CompletedTask;
    }

    public Task<byte[]> SendReceiveAsync(byte[] request, CancellationToken ct)
    {
        SentRequests.Add(request);

        if (_responses.Count == 0)
        {
            throw new InvalidOperationException("No queued response available for this request.");
        }

        return Task.FromResult(_responses.Dequeue());
    }

    public Task DisconnectAsync()
    {
        IsConnected = false;
        return Task.CompletedTask;
    }

    public ValueTask DisposeAsync() => ValueTask.CompletedTask;
}
