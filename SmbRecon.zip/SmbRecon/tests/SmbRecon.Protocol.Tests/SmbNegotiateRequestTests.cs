// SmbRecon.Protocol.Tests / SmbNegotiateRequestTests.cs
// TODO: implement serialise/parse round-trip tests
