// SmbRecon.Protocol.Tests / SmbNegotiateResponseTests.cs
// TODO: implement tests against captured fixtures in Fixtures/
