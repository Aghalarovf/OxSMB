// SmbRecon.Modules.Common.Tests / Smbv1DetectorTests.cs
// TODO: implement tests
