using System.Buffers.Binary;
using SmbRecon.Core.Abstractions;
using SmbRecon.Core.Models;
using SmbRecon.Core.Tests.Mocks;
using SmbRecon.Modules.Common;
using Xunit;

namespace SmbRecon.Modules.Common.Tests;

public class SmbDialectProberTests
{
    private sealed class FixedTransportFactory : ISmbTransportFactory
    {
        private readonly ISmbTransport _transport;

        public FixedTransportFactory(ISmbTransport transport) => _transport = transport;

        public ISmbTransport Create(SmbTarget target) => _transport;
    }

    [Fact]
    public async Task DetectsSmb311_WhenServerAnswersDirectlyWithConcreteDialect()
    {
        var frame = BuildSmb2NegotiateResponseFrame(
            dialectRevision: 0x0311,
            securityMode: 0x0001,
            capabilities: 0x00000041,
            maxTransactSize: 8388608,
            maxReadSize: 8388608,
            maxWriteSize: 8388608);

        var transport = new MockSmbTransport(frame);
        var factory = new FixedTransportFactory(transport);
        var tool = new SmbDialectProber(factory);

        var result = await tool.RunAsync(new SmbTarget("127.0.0.1"), CancellationToken.None);

        Assert.True(result.Success);

        var maxDialect = result.Findings.Single(f => f.Key == "smb.dialect.max");
        Assert.Equal(SmbDialect.Smb311, maxDialect.Value);

        var smb1Only = result.Findings.Single(f => f.Key == "smb.dialect.smb1_only");
        Assert.Equal(false, smb1Only.Value);

        var encryption = result.Findings.Single(f => f.Key == "smb.capability.encryption");
        Assert.Equal(true, encryption.Value);

        Assert.Single(transport.SentRequests);
    }

    [Fact]
    public async Task FollowsUpWithFullNegotiate_WhenServerAnswersWithWildcard()
    {
        var wildcardFrame = BuildSmb2NegotiateResponseFrame(
            dialectRevision: 0x02FF,
            securityMode: 0x0001,
            capabilities: 0,
            maxTransactSize: 0,
            maxReadSize: 0,
            maxWriteSize: 0);

        var finalFrame = BuildSmb2NegotiateResponseFrame(
            dialectRevision: 0x0302,
            securityMode: 0x0003,
            capabilities: 0x00000001,
            maxTransactSize: 1048576,
            maxReadSize: 1048576,
            maxWriteSize: 1048576);

        var transport = new MockSmbTransport(wildcardFrame, finalFrame);
        var factory = new FixedTransportFactory(transport);
        var tool = new SmbDialectProber(factory);

        var result = await tool.RunAsync(new SmbTarget("127.0.0.1"), CancellationToken.None);

        Assert.True(result.Success);

        var maxDialect = result.Findings.Single(f => f.Key == "smb.dialect.max");
        Assert.Equal(SmbDialect.Smb302, maxDialect.Value);

        var signingRequired = result.Findings.Single(f => f.Key == "smb.signing.required");
        Assert.Equal(true, signingRequired.Value);

        Assert.Equal(2, transport.SentRequests.Count);
    }

    [Fact]
    public async Task DetectsSmb1Only_WhenServerNeverUpgradesToSmb2()
    {
        var frame = BuildSmb1NegotiateResponseFrame();

        var transport = new MockSmbTransport(frame);
        var factory = new FixedTransportFactory(transport);
        var tool = new SmbDialectProber(factory);

        var result = await tool.RunAsync(new SmbTarget("127.0.0.1"), CancellationToken.None);

        Assert.True(result.Success);

        var maxDialect = result.Findings.Single(f => f.Key == "smb.dialect.max");
        Assert.Equal(SmbDialect.Smb1, maxDialect.Value);

        var smb1Only = result.Findings.Single(f => f.Key == "smb.dialect.smb1_only");
        Assert.Equal(true, smb1Only.Value);

        Assert.Single(transport.SentRequests);
    }

    private static byte[] BuildSmb2NegotiateResponseFrame(
        ushort dialectRevision,
        ushort securityMode,
        uint capabilities,
        uint maxTransactSize,
        uint maxReadSize,
        uint maxWriteSize)
    {
        var frame = new byte[64 + 64];
        var span = frame.AsSpan();

        span[0] = 0xFE;
        span[1] = 0x53;
        span[2] = 0x4D;
        span[3] = 0x42;

        var body = span.Slice(64);
        BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(0, 2), 65);
        BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(2, 2), securityMode);
        BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(4, 2), dialectRevision);
        Guid.NewGuid().ToByteArray().CopyTo(body.Slice(8, 16));
        BinaryPrimitives.WriteUInt32LittleEndian(body.Slice(24, 4), capabilities);
        BinaryPrimitives.WriteUInt32LittleEndian(body.Slice(28, 4), maxTransactSize);
        BinaryPrimitives.WriteUInt32LittleEndian(body.Slice(32, 4), maxReadSize);
        BinaryPrimitives.WriteUInt32LittleEndian(body.Slice(36, 4), maxWriteSize);

        return frame;
    }

    private static byte[] BuildSmb1NegotiateResponseFrame()
    {
        var frame = new byte[36];
        frame[0] = 0xFF;
        frame[1] = 0x53;
        frame[2] = 0x4D;
        frame[3] = 0x42;
        frame[4] = 0x72;
        return frame;
    }
}
