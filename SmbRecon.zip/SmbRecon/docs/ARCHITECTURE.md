# SmbRecon — Architecture

## Reference rules

| Referencing project | May reference |
|---|---|
| `Core` | nothing (pure abstractions) |
| `Protocol` | `Core` only |
| `Modules.*` | `Core` + `Protocol` only |
| `Output` | `Core` only |
| `Cli` | all of the above |

> **Rule:** No module project may ever reference another module project.
> Violations are caught by the Roslyn analyzer added in Step 10.

## Layers

- **Core** — immutable record models (`SmbTarget`, `ToolResult`, `Finding`, enums) and
  the `ISmbTool` / `ISmbTransport` abstractions. No I/O, no `System.Net`.
- **Protocol** — all byte-level SMB/RPC packet construction and parsing, plus the real
  `TcpSmbTransport`.
- **Modules.*** — the 77 tools, grouped by category. Each tool implements `ISmbTool`
  (usually via `SmbToolBase`) and is registered through a static `GetTools()` method.
- **Output** — `IReporter` implementations (console, JSON, Markdown).
- **Cli** — composition root: argument parsing, module discovery, the safety pipeline,
  thread dispatch, and reporting.
