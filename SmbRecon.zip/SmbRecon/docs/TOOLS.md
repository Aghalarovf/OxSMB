# SmbRecon — Tool Reference (77 tools)

Canonical list. `Name` here must exactly match `ISmbTool.Name` for each tool
(enforced by `scripts/validate_tools.py` in CI).

## Common (10) — `--common`

| # | Name | Transport | Description |
|---|---|---|---|
| 1 | SMBDialectProber | TcpClient → manual SMB Negotiate packet | Determines SMBv1/v2/v3 dialect support and the maximum dialect |
| 2 | SMBSigningAuditor | TBD | TODO |
| 3 | SMBCapabilityScanner | TBD | TODO |
| 4 | SMBv1Detector | TBD | TODO |
| 5 | SMBEncryptionChecker | TBD | TODO |
| 6 | SMBPortMapper | TBD | TODO |
| 7 | SMBDialectDowngradeChecker | TBD | TODO |
| 8 | GuestAccessProber | TBD | TODO |
| 9 | SMBServerStringExtractor | TBD | TODO |
| 10 | SMBTimeoutBehaviorProber | TBD | TODO |

## SystemInfo (14) — `--system-info`
_Tools 11–24 — TODO_

## Domain (7) — `--domain`
_Tools 25–31 — TODO_

## DC (8) — `--dc`
_Tools 32–39 — TODO_

## Enumeration (6) — `--enum`
_Tools 40–45 — TODO_

## Objects (4) — `--objects`
_Tools 46–49 — TODO_

## Vulns (4) — `--vulns`
_Tools 50–53 — TODO_

## ShareRecon (8) — `--shares`
_Tools 54–61 — TODO_

## AuthRelay (6) — `--auth`
_Tools 62–67 — TODO_

## PostEx (10) — `--postex`
_Tools 68–77 — TODO_
