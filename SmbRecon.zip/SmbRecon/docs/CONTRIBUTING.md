# Contributing to SmbRecon

## Adding a new module

Every module project must declare three public `const string` fields on its
`<Name>Module` static class:

| Field | Example | Used by |
|---|---|---|
| `Flag` | `"--common"` | CLI flag parser |
| `Category` | `"common"` | `ISmbTool.Category` cross-validation |
| `DisplayName` | `"Common SMB"` | `--list` output |

A CI test asserts that every discovered `ISmbTool.Category` matches the `Category`
constant of its hosting module, and that `ModuleLoader.DiscoverAll()` returns exactly
77 tools with no duplicate `Name`.

## Adding a new tool

1. Implement `ISmbTool` (normally by extending `SmbToolBase`).
2. Add the tool's name to `docs/TOOLS.md`.
3. Register it in its module's `GetTools()`.
4. Add a golden-file test using `MockSmbTransport` under the module's test project.

## Safety classification

Every tool declares an `ImpactLevel`:

- `Passive` — read-only observation, runs in `--safe` mode.
- `Active` — writes test artefacts or attempts auth; requires `--no-safe`.
- `Intrusive` — may cause disruption; requires `--allow-intrusive`.

Classify conservatively — when in doubt, pick the more restrictive level.
