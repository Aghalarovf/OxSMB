// SmbRecon.Modules.DC / DCModule.cs
// Step 6 — Module Registration System
// TODO: implement DCModule static class
//   - public const string Flag        = "--dc";
//   - public const string Category    = "dc";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
