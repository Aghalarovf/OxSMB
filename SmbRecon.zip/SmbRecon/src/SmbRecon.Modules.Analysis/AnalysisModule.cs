// SmbRecon.Modules.Analysis / AnalysisModule.cs
// Step 6 — Module Registration System
// TODO: implement AnalysisModule static class
//   - public const string Flag        = "--analysis";
//   - public const string Category    = "analysis";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
