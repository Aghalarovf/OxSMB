// SmbRecon.Modules.PostEx / PostExModule.cs
// Step 6 — Module Registration System
// TODO: implement PostExModule static class
//   - public const string Flag        = "--post-ex";
//   - public const string Category    = "post-ex";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
