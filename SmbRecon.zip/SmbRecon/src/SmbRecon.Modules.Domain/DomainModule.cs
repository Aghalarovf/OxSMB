// SmbRecon.Modules.Domain / DomainModule.cs
// Step 6 — Module Registration System
// TODO: implement DomainModule static class
//   - public const string Flag        = "--domain";
//   - public const string Category    = "domain";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
