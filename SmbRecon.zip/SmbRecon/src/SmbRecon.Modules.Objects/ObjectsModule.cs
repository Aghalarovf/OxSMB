// SmbRecon.Modules.Objects / ObjectsModule.cs
// Step 6 — Module Registration System
// TODO: implement ObjectsModule static class
//   - public const string Flag        = "--objects";
//   - public const string Category    = "objects";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
