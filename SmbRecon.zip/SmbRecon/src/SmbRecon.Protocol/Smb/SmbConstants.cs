namespace SmbRecon.Protocol.Smb;

public static class SmbConstants
{
    public static readonly byte[] Smb1ProtocolId = { 0xFF, 0x53, 0x4D, 0x42 };
    public static readonly byte[] Smb2ProtocolId = { 0xFE, 0x53, 0x4D, 0x42 };

    public const ushort SMB2_COMMAND_NEGOTIATE = 0x0000;

    public const ushort DIALECT_SMB_2_0_2 = 0x0202;
    public const ushort DIALECT_SMB_2_1_0 = 0x0210;
    public const ushort DIALECT_SMB_3_0_0 = 0x0300;
    public const ushort DIALECT_SMB_3_0_2 = 0x0302;
    public const ushort DIALECT_SMB_3_1_1 = 0x0311;
    public const ushort DIALECT_SMB2_WILDCARD = 0x02FF;

    public static readonly ushort[] AllSmb2Dialects =
    {
        DIALECT_SMB_2_0_2,
        DIALECT_SMB_2_1_0,
        DIALECT_SMB_3_0_0,
        DIALECT_SMB_3_0_2,
        DIALECT_SMB_3_1_1
    };

    public const ushort NEGOTIATE_SIGNING_ENABLED = 0x0001;
    public const ushort NEGOTIATE_SIGNING_REQUIRED = 0x0002;

    public const uint CAP_DFS = 0x00000001;
    public const uint CAP_LEASING = 0x00000002;
    public const uint CAP_LARGE_MTU = 0x00000004;
    public const uint CAP_MULTI_CHANNEL = 0x00000008;
    public const uint CAP_PERSISTENT_HANDLES = 0x00000010;
    public const uint CAP_DIRECTORY_LEASING = 0x00000020;
    public const uint CAP_ENCRYPTION = 0x00000040;
    public const uint CAP_NOTIFICATIONS = 0x00000080;
    public const uint CAP_COMPRESSION = 0x00000100;

    public const int Smb2HeaderLength = 64;
    public const ushort NegotiateRequestStructureSize = 36;
}
