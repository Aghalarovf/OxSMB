// SmbRecon.Protocol / Smb / SmbPacketParser.cs
// Step 5 — Protocol/RPC Layer
// TODO: entry point byte[] -> ISmbPacket
