// SmbRecon.Protocol / Smb / SmbSessionSetupResponse.cs
// Step 5 — Protocol/RPC Layer
// TODO: implement session setup response parser
