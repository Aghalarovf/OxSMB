// SmbRecon.Protocol / Smb / SmbSessionSetupRequest.cs
// Step 5 — Protocol/RPC Layer
// TODO: implement session setup request builder
