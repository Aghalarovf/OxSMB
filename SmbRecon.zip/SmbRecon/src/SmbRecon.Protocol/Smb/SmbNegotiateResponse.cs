using System.Buffers.Binary;
using SmbRecon.Core.Models;

namespace SmbRecon.Protocol.Smb;

public sealed record SmbNegotiateResponse(
    bool IsSmb2,
    SmbDialect Dialect,
    ushort RawDialectRevision,
    ushort SecurityMode,
    uint Capabilities,
    Guid ServerGuid,
    uint MaxTransactSize,
    uint MaxReadSize,
    uint MaxWriteSize)
{
    public bool SigningEnabled => (SecurityMode & SmbConstants.NEGOTIATE_SIGNING_ENABLED) != 0;
    public bool SigningRequired => (SecurityMode & SmbConstants.NEGOTIATE_SIGNING_REQUIRED) != 0;
    public bool IsWildcardDialect => RawDialectRevision == SmbConstants.DIALECT_SMB2_WILDCARD;

    public static SmbNegotiateResponse Parse(ReadOnlySpan<byte> frame)
    {
        if (frame.Length < 4)
        {
            throw new InvalidOperationException("Frame too short to contain an SMB header.");
        }

        var protocolId = frame.Slice(0, 4);

        if (protocolId.SequenceEqual(SmbConstants.Smb1ProtocolId))
        {
            return new SmbNegotiateResponse(
                IsSmb2: false,
                Dialect: SmbDialect.Smb1,
                RawDialectRevision: 0,
                SecurityMode: 0,
                Capabilities: 0,
                ServerGuid: Guid.Empty,
                MaxTransactSize: 0,
                MaxReadSize: 0,
                MaxWriteSize: 0);
        }

        if (!protocolId.SequenceEqual(SmbConstants.Smb2ProtocolId))
        {
            throw new InvalidOperationException("Response is neither a valid SMB1 nor SMB2 frame.");
        }

        if (frame.Length < SmbConstants.Smb2HeaderLength + 8)
        {
            throw new InvalidOperationException("SMB2 frame too short to contain a NEGOTIATE response body.");
        }

        var body = frame.Slice(SmbConstants.Smb2HeaderLength);

        var securityMode = BinaryPrimitives.ReadUInt16LittleEndian(body.Slice(2, 2));
        var dialectRevision = BinaryPrimitives.ReadUInt16LittleEndian(body.Slice(4, 2));

        var serverGuid = Guid.Empty;
        var capabilities = 0u;
        var maxTransactSize = 0u;
        var maxReadSize = 0u;
        var maxWriteSize = 0u;

        if (body.Length >= 64)
        {
            serverGuid = new Guid(body.Slice(8, 16));
            capabilities = BinaryPrimitives.ReadUInt32LittleEndian(body.Slice(24, 4));
            maxTransactSize = BinaryPrimitives.ReadUInt32LittleEndian(body.Slice(28, 4));
            maxReadSize = BinaryPrimitives.ReadUInt32LittleEndian(body.Slice(32, 4));
            maxWriteSize = BinaryPrimitives.ReadUInt32LittleEndian(body.Slice(36, 4));
        }

        return new SmbNegotiateResponse(
            IsSmb2: true,
            Dialect: MapDialect(dialectRevision),
            RawDialectRevision: dialectRevision,
            SecurityMode: securityMode,
            Capabilities: capabilities,
            ServerGuid: serverGuid,
            MaxTransactSize: maxTransactSize,
            MaxReadSize: maxReadSize,
            MaxWriteSize: maxWriteSize);
    }

    private static SmbDialect MapDialect(ushort revision) => revision switch
    {
        SmbConstants.DIALECT_SMB_2_0_2 => SmbDialect.Smb202,
        SmbConstants.DIALECT_SMB_2_1_0 => SmbDialect.Smb210,
        SmbConstants.DIALECT_SMB_3_0_0 => SmbDialect.Smb300,
        SmbConstants.DIALECT_SMB_3_0_2 => SmbDialect.Smb302,
        SmbConstants.DIALECT_SMB_3_1_1 => SmbDialect.Smb311,
        _ => SmbDialect.Unknown
    };
}
