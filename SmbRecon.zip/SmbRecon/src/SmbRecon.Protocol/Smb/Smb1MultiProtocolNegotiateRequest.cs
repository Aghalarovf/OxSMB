using System.Buffers.Binary;
using System.Text;

namespace SmbRecon.Protocol.Smb;

public sealed class Smb1MultiProtocolNegotiateRequest
{
    private static readonly string[] DefaultDialects =
    {
        "PC NETWORK PROGRAM 1.0",
        "LANMAN1.0",
        "Windows for Workgroups 3.1a",
        "LM1.2X002",
        "LANMAN2.1",
        "NT LM 0.12",
        "SMB 2.002",
        "SMB 2.???"
    };

    private readonly string[] _dialects;

    public Smb1MultiProtocolNegotiateRequest(string[]? dialects = null)
    {
        _dialects = dialects ?? DefaultDialects;
    }

    public byte[] ToBytes()
    {
        var dialectBuffer = BuildDialectBuffer();

        var headerLength = 32;
        var wordCountLength = 1;
        var byteCountLength = 2;
        var totalLength = headerLength + wordCountLength + byteCountLength + dialectBuffer.Length;

        var buffer = new byte[totalLength];
        var span = buffer.AsSpan();

        WriteHeader(span);

        span[headerLength] = 0x00;

        BinaryPrimitives.WriteUInt16LittleEndian(
            span.Slice(headerLength + wordCountLength, byteCountLength),
            (ushort)dialectBuffer.Length);

        dialectBuffer.CopyTo(span.Slice(headerLength + wordCountLength + byteCountLength));

        return buffer;
    }

    private static void WriteHeader(Span<byte> span)
    {
        SmbConstants.Smb1ProtocolId.CopyTo(span.Slice(0, 4));
        span[4] = 0x72;
        BinaryPrimitives.WriteUInt32LittleEndian(span.Slice(5, 4), 0);
        span[9] = 0x18;
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(10, 2), 0xC843);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(12, 2), 0);
        BinaryPrimitives.WriteUInt64LittleEndian(span.Slice(14, 8), 0);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(22, 2), 0);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(24, 2), 0);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(26, 2), 0);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(28, 2), 0);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(30, 2), 0);
    }

    private byte[] BuildDialectBuffer()
    {
        using var stream = new MemoryStream();

        foreach (var dialect in _dialects)
        {
            stream.WriteByte(0x02);
            var bytes = Encoding.ASCII.GetBytes(dialect);
            stream.Write(bytes, 0, bytes.Length);
            stream.WriteByte(0x00);
        }

        return stream.ToArray();
    }
}
