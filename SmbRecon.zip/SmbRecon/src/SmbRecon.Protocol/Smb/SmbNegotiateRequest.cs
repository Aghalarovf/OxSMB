using System.Buffers.Binary;

namespace SmbRecon.Protocol.Smb;

public sealed class SmbNegotiateRequest
{
    private readonly ushort[] _dialects;
    private readonly Guid _clientGuid;
    private readonly bool _includePreauthContext;

    public SmbNegotiateRequest(ushort[]? dialects = null, Guid? clientGuid = null)
    {
        _dialects = dialects ?? SmbConstants.AllSmb2Dialects;
        _clientGuid = clientGuid ?? Guid.NewGuid();
        _includePreauthContext = Array.IndexOf(_dialects, SmbConstants.DIALECT_SMB_3_1_1) >= 0;
    }

    public byte[] ToBytes()
    {
        var dialectBytes = _dialects.Length * 2;
        var fixedBodyLength = SmbConstants.NegotiateRequestStructureSize;
        var preHeaderAndBody = SmbConstants.Smb2HeaderLength + fixedBodyLength + dialectBytes;

        var contextPadding = 0;
        var contextBlock = Array.Empty<byte>();
        var contextOffset = 0;
        var contextCount = 0;

        if (_includePreauthContext)
        {
            var unalignedOffset = preHeaderAndBody;
            var remainder = unalignedOffset % 8;
            contextPadding = remainder == 0 ? 0 : 8 - remainder;
            contextOffset = unalignedOffset + contextPadding;
            contextCount = 1;
            contextBlock = BuildPreauthIntegrityContext();
        }

        var totalLength = preHeaderAndBody + contextPadding + contextBlock.Length;
        var buffer = new byte[totalLength];
        var span = buffer.AsSpan();

        WriteHeader(span);

        var body = span.Slice(SmbConstants.Smb2HeaderLength);
        BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(0, 2), SmbConstants.NegotiateRequestStructureSize);
        BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(2, 2), (ushort)_dialects.Length);
        BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(4, 2), SmbConstants.NEGOTIATE_SIGNING_ENABLED);
        BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(6, 2), 0);
        BinaryPrimitives.WriteUInt32LittleEndian(body.Slice(8, 4), 0);
        _clientGuid.ToByteArray().CopyTo(body.Slice(12, 16));

        if (_includePreauthContext)
        {
            BinaryPrimitives.WriteUInt32LittleEndian(body.Slice(28, 4), (uint)contextOffset);
            BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(32, 2), (ushort)contextCount);
            BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(34, 2), 0);
        }
        else
        {
            BinaryPrimitives.WriteUInt32LittleEndian(body.Slice(28, 4), 0);
            BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(32, 2), 0);
            BinaryPrimitives.WriteUInt16LittleEndian(body.Slice(34, 2), 0);
        }

        var dialectSpan = body.Slice(36, dialectBytes);
        for (var i = 0; i < _dialects.Length; i++)
        {
            BinaryPrimitives.WriteUInt16LittleEndian(dialectSpan.Slice(i * 2, 2), _dialects[i]);
        }

        if (_includePreauthContext)
        {
            contextBlock.CopyTo(buffer, contextOffset);
        }

        return buffer;
    }

    private void WriteHeader(Span<byte> span)
    {
        SmbConstants.Smb2ProtocolId.CopyTo(span.Slice(0, 4));
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(4, 2), SmbConstants.Smb2HeaderLength);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(6, 2), 0);
        BinaryPrimitives.WriteUInt32LittleEndian(span.Slice(8, 4), 0);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(12, 2), SmbConstants.SMB2_COMMAND_NEGOTIATE);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(14, 2), 1);
        BinaryPrimitives.WriteUInt32LittleEndian(span.Slice(16, 4), 0);
        BinaryPrimitives.WriteUInt32LittleEndian(span.Slice(20, 4), 0);
        BinaryPrimitives.WriteUInt64LittleEndian(span.Slice(24, 8), 0);
        BinaryPrimitives.WriteUInt32LittleEndian(span.Slice(32, 4), 0);
        BinaryPrimitives.WriteUInt32LittleEndian(span.Slice(36, 4), 0);
        BinaryPrimitives.WriteUInt64LittleEndian(span.Slice(40, 8), 0);
    }

    private static byte[] BuildPreauthIntegrityContext()
    {
        var salt = new byte[32];
        Random.Shared.NextBytes(salt);

        var dataLength = 2 + 2 + 2 + salt.Length;
        var buffer = new byte[8 + dataLength];
        var span = buffer.AsSpan();

        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(0, 2), 0x0001);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(2, 2), (ushort)dataLength);
        BinaryPrimitives.WriteUInt32LittleEndian(span.Slice(4, 4), 0);

        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(8, 2), 1);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(10, 2), (ushort)salt.Length);
        BinaryPrimitives.WriteUInt16LittleEndian(span.Slice(12, 2), 0x0001);
        salt.CopyTo(span.Slice(14, salt.Length));

        return buffer;
    }
}
