// SmbRecon.Protocol / Rpc / RpcBindAck.cs
// Step 5 — Protocol/RPC Layer
// TODO: DCE/RPC Bind Ack PDU parser
