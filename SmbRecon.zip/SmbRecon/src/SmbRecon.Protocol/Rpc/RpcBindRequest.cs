// SmbRecon.Protocol / Rpc / RpcBindRequest.cs
// Step 5 — Protocol/RPC Layer
// TODO: DCE/RPC Bind PDU
