// SmbRecon.Protocol / Rpc / RpcChannel.cs
// Step 5 — Protocol/RPC Layer
// TODO: binds a named pipe (\pipe\svcctl etc.) over ISmbTransport
