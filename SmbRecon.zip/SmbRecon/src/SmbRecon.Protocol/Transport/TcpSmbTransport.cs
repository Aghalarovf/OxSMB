using System.Net.Sockets;
using SmbRecon.Core.Abstractions;
using SmbRecon.Core.Models;

namespace SmbRecon.Protocol.Transport;

public sealed class TcpSmbTransport : ISmbTransport
{
    private TcpClient? _tcp;
    private NetworkStream? _stream;

    public bool IsConnected => _tcp is { Connected: true };

    public async Task ConnectAsync(SmbTarget target, CancellationToken ct)
    {
        _tcp = new TcpClient();

        using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeoutCts.CancelAfter(target.EffectiveTimeout);

        try
        {
            await _tcp.ConnectAsync(target.Host, target.Port, timeoutCts.Token);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            throw new TimeoutException($"Connection to {target.Host}:{target.Port} timed out.");
        }

        _stream = _tcp.GetStream();
    }

    public async Task<byte[]> SendReceiveAsync(byte[] request, CancellationToken ct)
    {
        if (_stream is null)
        {
            throw new InvalidOperationException("Transport is not connected.");
        }

        var framed = FrameMessage(request);
        await _stream.WriteAsync(framed, ct);

        return await ReadFrameAsync(_stream, ct);
    }

    public Task DisconnectAsync()
    {
        _stream?.Close();
        _tcp?.Close();
        _stream = null;
        return Task.CompletedTask;
    }

    public async ValueTask DisposeAsync()
    {
        await DisconnectAsync();
    }

    private static byte[] FrameMessage(byte[] payload)
    {
        if (payload.Length > 0x00FFFFFF)
        {
            throw new ArgumentOutOfRangeException(nameof(payload), "Payload exceeds NetBIOS session message limit.");
        }

        var framed = new byte[4 + payload.Length];
        var lengthField = (uint)payload.Length;

        framed[0] = 0x00;
        framed[1] = (byte)((lengthField >> 16) & 0xFF);
        framed[2] = (byte)((lengthField >> 8) & 0xFF);
        framed[3] = (byte)(lengthField & 0xFF);

        payload.CopyTo(framed, 4);
        return framed;
    }

    private static async Task<byte[]> ReadFrameAsync(NetworkStream stream, CancellationToken ct)
    {
        var header = await ReadExactAsync(stream, 4, ct);

        var length = (header[1] << 16) | (header[2] << 8) | header[3];
        if (length == 0)
        {
            return Array.Empty<byte>();
        }

        return await ReadExactAsync(stream, length, ct);
    }

    private static async Task<byte[]> ReadExactAsync(NetworkStream stream, int count, CancellationToken ct)
    {
        var buffer = new byte[count];
        var offset = 0;

        while (offset < count)
        {
            var read = await stream.ReadAsync(buffer.AsMemory(offset, count - offset), ct);
            if (read == 0)
            {
                throw new IOException("Remote host closed the connection before the full frame was received.");
            }

            offset += read;
        }

        return buffer;
    }
}
