using SmbRecon.Core.Abstractions;
using SmbRecon.Core.Models;

namespace SmbRecon.Protocol.Transport;

public sealed class DefaultSmbTransportFactory : ISmbTransportFactory
{
    public ISmbTransport Create(SmbTarget target) => new TcpSmbTransport();
}
