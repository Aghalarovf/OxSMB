// SmbRecon.Modules.AuthRelay / AuthRelayModule.cs
// Step 6 — Module Registration System
// TODO: implement AuthRelayModule static class
//   - public const string Flag        = "--auth-relay";
//   - public const string Category    = "auth-relay";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
