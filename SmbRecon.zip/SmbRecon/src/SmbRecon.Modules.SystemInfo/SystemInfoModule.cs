// SmbRecon.Modules.SystemInfo / SystemInfoModule.cs
// Step 6 — Module Registration System
// TODO: implement SystemInfoModule static class
//   - public const string Flag        = "--system-info";
//   - public const string Category    = "system-info";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
