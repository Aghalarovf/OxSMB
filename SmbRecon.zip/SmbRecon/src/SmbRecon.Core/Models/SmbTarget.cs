namespace SmbRecon.Core.Models;

public sealed record SmbTarget(
    string Host,
    int Port = 445,
    string? Username = null,
    string? Password = null,
    string? NtlmHash = null,
    string? Domain = null,
    TimeSpan Timeout = default)
{
    public static readonly TimeSpan DefaultTimeout = TimeSpan.FromSeconds(5);

    public TimeSpan EffectiveTimeout => Timeout == default ? DefaultTimeout : Timeout;
}
