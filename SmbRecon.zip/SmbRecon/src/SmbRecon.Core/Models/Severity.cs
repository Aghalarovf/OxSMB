namespace SmbRecon.Core.Models;

public enum Severity
{
    Info,
    Low,
    Medium,
    High,
    Critical
}
