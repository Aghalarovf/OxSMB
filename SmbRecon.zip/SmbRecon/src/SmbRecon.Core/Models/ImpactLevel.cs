namespace SmbRecon.Core.Models;

public enum ImpactLevel
{
    Passive,
    Active,
    Intrusive
}
