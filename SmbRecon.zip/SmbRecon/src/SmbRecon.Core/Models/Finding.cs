namespace SmbRecon.Core.Models;

public sealed record Finding(
    Severity Severity,
    string Key,
    string Summary,
    object? Value = null,
    IReadOnlyDictionary<string, object>? Detail = null);
