namespace SmbRecon.Core.Models;

public enum SmbDialect
{
    Unknown,
    Smb1,
    Smb202,
    Smb210,
    Smb300,
    Smb302,
    Smb311
}
