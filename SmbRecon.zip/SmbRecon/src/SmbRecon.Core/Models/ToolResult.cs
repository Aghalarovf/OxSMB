namespace SmbRecon.Core.Models;

public sealed record ToolResult(
    string ToolName,
    bool Success,
    IReadOnlyList<Finding> Findings,
    string? RawError = null,
    TimeSpan Elapsed = default);
