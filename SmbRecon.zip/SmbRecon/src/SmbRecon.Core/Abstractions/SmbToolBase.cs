using System.Diagnostics;
using SmbRecon.Core.Models;

namespace SmbRecon.Core.Abstractions;

public abstract class SmbToolBase : ISmbTool
{
    public abstract string Name { get; }
    public abstract string Category { get; }
    public abstract string Description { get; }
    public abstract ImpactLevel Impact { get; }
    public virtual bool RequiresAuthentication => false;

    public async Task<ToolResult> RunAsync(SmbTarget target, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        try
        {
            var findings = await RunCoreAsync(target, ct);
            return new ToolResult(Name, true, findings, Elapsed: sw.Elapsed);
        }
        catch (OperationCanceledException)
        {
            return new ToolResult(Name, false, Array.Empty<Finding>(), "Cancelled", sw.Elapsed);
        }
        catch (Exception ex)
        {
            return new ToolResult(Name, false, Array.Empty<Finding>(), ex.Message, sw.Elapsed);
        }
    }

    protected abstract Task<IReadOnlyList<Finding>> RunCoreAsync(SmbTarget target, CancellationToken ct);
}
