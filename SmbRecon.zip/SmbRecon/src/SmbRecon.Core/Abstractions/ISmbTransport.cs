using SmbRecon.Core.Models;

namespace SmbRecon.Core.Abstractions;

public interface ISmbTransport : IAsyncDisposable
{
    bool IsConnected { get; }

    Task ConnectAsync(SmbTarget target, CancellationToken ct);

    Task<byte[]> SendReceiveAsync(byte[] request, CancellationToken ct);

    Task DisconnectAsync();
}
