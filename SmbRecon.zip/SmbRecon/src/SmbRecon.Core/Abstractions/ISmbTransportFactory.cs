using SmbRecon.Core.Models;

namespace SmbRecon.Core.Abstractions;

public interface ISmbTransportFactory
{
    ISmbTransport Create(SmbTarget target);
}
