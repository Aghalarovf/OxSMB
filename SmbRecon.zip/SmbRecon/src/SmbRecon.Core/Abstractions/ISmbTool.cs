using SmbRecon.Core.Models;

namespace SmbRecon.Core.Abstractions;

public interface ISmbTool
{
    string Name { get; }

    string Category { get; }

    string Description { get; }

    ImpactLevel Impact { get; }

    bool RequiresAuthentication { get; }

    Task<ToolResult> RunAsync(SmbTarget target, CancellationToken ct);
}
