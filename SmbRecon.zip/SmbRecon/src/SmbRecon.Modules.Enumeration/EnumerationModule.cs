// SmbRecon.Modules.Enumeration / EnumerationModule.cs
// Step 6 — Module Registration System
// TODO: implement EnumerationModule static class
//   - public const string Flag        = "--enumeration";
//   - public const string Category    = "enumeration";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
