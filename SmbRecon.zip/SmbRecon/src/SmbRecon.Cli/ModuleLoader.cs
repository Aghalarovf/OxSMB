// SmbRecon.Cli / ModuleLoader.cs
// Step 6 — Module Registration System
// TODO: implement ModuleLoader.DiscoverAll() via assembly scanning
