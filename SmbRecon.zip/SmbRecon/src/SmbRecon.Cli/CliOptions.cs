// SmbRecon.Cli / CliOptions.cs
// Step 7 — CLI Skeleton & Flag Map
// TODO: implement CliOptions (Host, Port, Username, Password, Hash, Domain, Timeout,
//       All, Categories, Only, Safe, AllowIntrusive, Format, OutFile, Threads, List, Help)
// TODO: implement OutputFormat enum (Console, Json, Markdown)
//
// Flag naming:
//   --host        (was --target) -> binds to CliOptions.Host, maps onto SmbTarget.Host
//   --hash / -H   -> both aliases must bind to the same CliOptions.Hash property;
//                    register "-H" as a short-form alias for "--hash" in CliParser
