// SmbRecon.Cli / Program.cs
// Entry point.
// TODO: parse CliOptions -> ModuleLoader.DiscoverAll() -> SafetyFilter.Apply()
//       -> ReporterFactory.Create() -> dispatch tools -> report results
