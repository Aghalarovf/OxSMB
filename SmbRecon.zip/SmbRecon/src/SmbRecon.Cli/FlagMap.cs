// SmbRecon.Cli / FlagMap.cs
// Step 7 — CLI Skeleton & Flag Map
// TODO: implement FlagMap.FlagToCategory dictionary
