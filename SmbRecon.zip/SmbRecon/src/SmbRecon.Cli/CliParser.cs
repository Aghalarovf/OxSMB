// SmbRecon.Cli / CliParser.cs
// Step 7 — CLI Skeleton & Flag Map
// TODO: implement argument parsing -> CliOptions
// TODO: "--host" is the target flag (not "--target")
// TODO: "--hash" and "-H" must both resolve to CliOptions.Hash (register -H as a short alias)
