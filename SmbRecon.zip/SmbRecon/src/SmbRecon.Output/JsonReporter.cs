// SmbRecon.Output / JsonReporter.cs
// Step 9 — Output & Reporting Contracts
// TODO: implement JsonReporter : IReporter using System.Text.Json
