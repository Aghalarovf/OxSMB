// SmbRecon.Output / ReporterFactory.cs
// Step 9 — Output & Reporting Contracts
// TODO: implement ReporterFactory.Create(OutputFormat, TextWriter?)
