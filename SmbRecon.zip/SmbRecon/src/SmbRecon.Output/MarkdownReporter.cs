// SmbRecon.Output / MarkdownReporter.cs
// Step 9 — Output & Reporting Contracts
// TODO: implement MarkdownReporter : IReporter with severity-badge mapping
