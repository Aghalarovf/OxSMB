// SmbRecon.Output / ConsoleReporter.cs
// Step 9 — Output & Reporting Contracts
// TODO: implement ConsoleReporter : IReporter with ANSI colour output
