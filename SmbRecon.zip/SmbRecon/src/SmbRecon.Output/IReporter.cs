// SmbRecon.Output / IReporter.cs
// Step 9 — Output & Reporting Contracts
// TODO: implement IReporter interface (Begin, Report, End)
