using SmbRecon.Core.Abstractions;

namespace SmbRecon.Modules.Common;

public static class CommonModule
{
    public const string Flag = "--common";
    public const string Category = "common";
    public const string DisplayName = "Common SMB";

    public static IEnumerable<ISmbTool> GetTools() =>
        new ISmbTool[]
        {
            new SmbDialectProber()
        };
}
