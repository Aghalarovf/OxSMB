using SmbRecon.Core.Abstractions;
using SmbRecon.Core.Models;
using SmbRecon.Protocol.Smb;
using SmbRecon.Protocol.Transport;

namespace SmbRecon.Modules.Common;

public sealed class SmbDialectProber : SmbToolBase
{
    private readonly ISmbTransportFactory _transportFactory;

    public SmbDialectProber() : this(new DefaultSmbTransportFactory())
    {
    }

    public SmbDialectProber(ISmbTransportFactory transportFactory)
    {
        _transportFactory = transportFactory;
    }

    public override string Name => "SMBDialectProber";
    public override string Category => "common";
    public override string Description => "Determines SMBv1/v2/v3 dialect support and the maximum negotiated dialect.";
    public override ImpactLevel Impact => ImpactLevel.Passive;

    protected override async Task<IReadOnlyList<Finding>> RunCoreAsync(SmbTarget target, CancellationToken ct)
    {
        var findings = new List<Finding>();

        await using var transport = _transportFactory.Create(target);
        await transport.ConnectAsync(target, ct);

        var probeRequest = new Smb1MultiProtocolNegotiateRequest();
        var probeResponseBytes = await transport.SendReceiveAsync(probeRequest.ToBytes(), ct);
        var probeResponse = SmbNegotiateResponse.Parse(probeResponseBytes);

        if (!probeResponse.IsSmb2)
        {
            await transport.DisconnectAsync();

            findings.Add(new Finding(
                Severity.High,
                "smb.dialect.max",
                "Server only negotiated the legacy SMBv1 dialect.",
                SmbDialect.Smb1));

            findings.Add(new Finding(
                Severity.High,
                "smb.dialect.smb1_only",
                "SMBv1 is the highest dialect offered by the server.",
                true));

            return findings;
        }

        var response = probeResponse;

        if (probeResponse.IsWildcardDialect)
        {
            var fullRequest = new SmbNegotiateRequest();
            var fullResponseBytes = await transport.SendReceiveAsync(fullRequest.ToBytes(), ct);
            response = SmbNegotiateResponse.Parse(fullResponseBytes);
        }

        await transport.DisconnectAsync();

        findings.Add(new Finding(
            Severity.Info,
            "smb.dialect.max",
            $"Maximum negotiated dialect: {FormatDialect(response.Dialect)}",
            response.Dialect));

        findings.Add(new Finding(
            Severity.Info,
            "smb.dialect.smb1_only",
            "Server negotiated SMBv2/SMBv3; SMBv1 was not used for this probe.",
            false));

        var dialectSeverity = response.Dialect switch
        {
            SmbDialect.Smb202 => Severity.Medium,
            SmbDialect.Smb210 => Severity.Low,
            SmbDialect.Unknown => Severity.Medium,
            _ => Severity.Info
        };

        if (dialectSeverity != Severity.Info)
        {
            findings.Add(new Finding(
                dialectSeverity,
                "smb.dialect.outdated",
                $"Negotiated dialect {FormatDialect(response.Dialect)} is older than SMBv3.0.0.",
                response.Dialect));
        }

        findings.Add(new Finding(
            Severity.Info,
            "smb.negotiate.server_guid",
            $"Server GUID: {response.ServerGuid}",
            response.ServerGuid.ToString()));

        findings.Add(new Finding(
            response.SigningRequired ? Severity.Info : Severity.Medium,
            "smb.signing.required",
            response.SigningRequired ? "Message signing is required by the server." : "Message signing is not required by the server.",
            response.SigningRequired));

        findings.Add(new Finding(
            Severity.Info,
            "smb.signing.enabled",
            response.SigningEnabled ? "Message signing is enabled." : "Message signing is disabled.",
            response.SigningEnabled));

        findings.Add(new Finding(
            Severity.Info,
            "smb.negotiate.capabilities",
            $"Raw capabilities bitmask: 0x{response.Capabilities:X8}",
            response.Capabilities));

        AddCapabilityFinding(findings, response.Capabilities, SmbConstants.CAP_ENCRYPTION,
            "smb.capability.encryption", "Server advertises SMB3 encryption support.");

        AddCapabilityFinding(findings, response.Capabilities, SmbConstants.CAP_COMPRESSION,
            "smb.capability.compression", "Server advertises SMB3.1.1 compression support.");

        AddCapabilityFinding(findings, response.Capabilities, SmbConstants.CAP_MULTI_CHANNEL,
            "smb.capability.multi_channel", "Server advertises SMB multichannel support.");

        if (response.MaxTransactSize > 0)
        {
            findings.Add(new Finding(
                Severity.Info,
                "smb.negotiate.max_transact_size",
                $"Max transact size: {response.MaxTransactSize} bytes",
                response.MaxTransactSize));
        }

        return findings;
    }

    private static void AddCapabilityFinding(
        List<Finding> findings, uint capabilities, uint flag, string key, string summary)
    {
        var present = (capabilities & flag) != 0;
        findings.Add(new Finding(Severity.Info, key, summary, present));
    }

    private static string FormatDialect(SmbDialect dialect) => dialect switch
    {
        SmbDialect.Smb1 => "SMBv1",
        SmbDialect.Smb202 => "SMBv2.0.2",
        SmbDialect.Smb210 => "SMBv2.1.0",
        SmbDialect.Smb300 => "SMBv3.0.0",
        SmbDialect.Smb302 => "SMBv3.0.2",
        SmbDialect.Smb311 => "SMBv3.1.1",
        _ => "Unknown"
    };
}
