// SmbRecon.Modules.Vulns / VulnsModule.cs
// Step 6 — Module Registration System
// TODO: implement VulnsModule static class
//   - public const string Flag        = "--vulnerabilities";
//   - public const string Category    = "vulnerabilities";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
