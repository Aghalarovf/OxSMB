// SmbRecon.Modules.ShareRecon / ShareReconModule.cs
// Step 6 — Module Registration System
// TODO: implement ShareReconModule static class
//   - public const string Flag        = "--share-recon";
//   - public const string Category    = "share-recon";
//   - public const string DisplayName = "...";
//   - public static IEnumerable<ISmbTool> GetTools() => ...
